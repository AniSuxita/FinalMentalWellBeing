package com.example.mentalwellbeing

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.contract.ActivityResultContracts
import com.bumptech.glide.Glide
import com.example.mentalwellbeing.databinding.FragmentChecklistBinding
import com.example.mentalwellbeing.databinding.FragmentProfileBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.ktx.storage
import java.io.ByteArrayOutputStream
import java.io.File


class ProfileFragment : Fragment() {

    private lateinit var binding: FragmentProfileBinding
    private lateinit var database: DatabaseReference
    private lateinit var uri: Uri

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_profile, container, false)

        binding = FragmentProfileBinding.bind(view)


     val storageRef = Firebase.storage.reference


        var useruid = FirebaseAuth.getInstance().currentUser?.uid


        database = FirebaseDatabase.getInstance().getReference("Users")
        database.child(useruid.toString()).get().addOnSuccessListener {
            val firstname = it.child("ufirstname").value
            val lastname = it.child("ulastname").value
            val username = it.child("username").value

            binding.textviewName.text = firstname.toString()
            binding.textviewLastname.text = lastname.toString()
            binding.textviewUsername.text = username.toString()
        }

        binding.logout.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("log out")
                .setMessage("are you sure?")
                .setNegativeButton("no") { dialog, which ->
                    dialog.dismiss()
                }
                .setPositiveButton("yes") { dialog, which ->
                    dialog.dismiss()
                    val intent = Intent(requireContext(),MainActivity::class.java)
                    startActivity(intent)
                    activity?.finish()
                    FirebaseAuth.getInstance().signOut()
                }
                .show()
        }

        storageRef.child("images/$useruid.jpg").downloadUrl.addOnSuccessListener {
            Glide.with(this).load(it).into(binding.profilepic)
        }

        val galleryImage = registerForActivityResult(
            ActivityResultContracts.GetContent(),
            ActivityResultCallback {
                binding.profilepic.setImageURI(it)

                    binding.profilepic.isDrawingCacheEnabled = true
                    binding.profilepic.buildDrawingCache()

                    val bitmap = (binding.profilepic.drawable as BitmapDrawable).bitmap
                    val baos = ByteArrayOutputStream()
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
                    val data = baos.toByteArray()

                storageRef.child("images/$useruid.jpg").putBytes(data)

                database.child(useruid.toString()).child("profilepic").setValue("$useruid.jpg")



            }
        )

        binding.addphoto.setOnClickListener{
            galleryImage.launch("image/*")

        }




        return view



    }


    override fun onStart() {
        super.onStart()
        val sharedPref = activity?.getSharedPreferences("sharedPref", Context.MODE_PRIVATE)
        val checkstatus = sharedPref!!.getBoolean("CheckboxStatus", false)

        if (checkstatus){
            binding.hotline.isChecked = true
            binding.hotlinenum.text = "psychological counseling services: 08 00 00 00 88"
            binding.number.text = "Psycho-social service center hotline: 2200220 (3025)"
        }

    }

}